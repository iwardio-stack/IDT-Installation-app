# IDT Installation Sign-Off Android App

Features:
- Client and installer details
- Offline local saving
- Finger-drawn client and installer signatures
- Site photo selection and preview
- Acceptance block
- PDF report generation
- Android share sheet for WhatsApp, email and other apps

## Build using GitHub on your phone
1. Upload all files and folders from this project to your repository root.
2. Ensure `.github/workflows/build-apk.yml` is included.
3. Open GitHub > Actions > Build IDT APK.
4. Run workflow, or push to `main`.
5. Open the successful run and download the `IDT-Installation-APK` artifact.
6. Extract the artifact and install the APK on your Samsung phone.

The PDF is shared using Android's standard share sheet. Select WhatsApp or Gmail/email.
