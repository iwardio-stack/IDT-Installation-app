package com.idt.installation;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    EditText job,date,client,address,contact,installer,work,defects,notes;
    CheckBox accepted,conditional;
    SignatureView clientSignature,installerSignature;
    ImageView photoPreview;
    Uri photoUri; File lastPdf;

    int[] editIds={R.id.job,R.id.date,R.id.client,R.id.address,R.id.contact,R.id.installer,R.id.work,R.id.defects,R.id.notes};

    @Override public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        job=findViewById(R.id.job);date=findViewById(R.id.date);client=findViewById(R.id.client);
        address=findViewById(R.id.address);contact=findViewById(R.id.contact);installer=findViewById(R.id.installer);
        work=findViewById(R.id.work);defects=findViewById(R.id.defects);notes=findViewById(R.id.notes);
        accepted=findViewById(R.id.accepted);conditional=findViewById(R.id.conditional);
        clientSignature=findViewById(R.id.clientSignature);installerSignature=findViewById(R.id.installerSignature);
        photoPreview=findViewById(R.id.photoPreview);
        date.setText(new SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(new Date()));
        findViewById(R.id.clearClient).setOnClickListener(v->clientSignature.clear());
        findViewById(R.id.clearInstaller).setOnClickListener(v->installerSignature.clear());
        findViewById(R.id.addPhoto).setOnClickListener(v->choosePhoto());
        findViewById(R.id.save).setOnClickListener(v->{saveForm();Toast.makeText(this,"Form saved",Toast.LENGTH_SHORT).show();});
        findViewById(R.id.pdf).setOnClickListener(v->{lastPdf=createPdf();Toast.makeText(this,"PDF report created",Toast.LENGTH_SHORT).show();});
        findViewById(R.id.share).setOnClickListener(v->{if(lastPdf==null)lastPdf=createPdf();sharePdf(lastPdf);});
        loadForm();
    }
    void choosePhoto(){Intent i=new Intent(Intent.ACTION_PICK,MediaStore.Images.Media.EXTERNAL_CONTENT_URI);startActivityForResult(i,44);}
    protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==44&&c==RESULT_OK&&d!=null){photoUri=d.getData();photoPreview.setImageURI(photoUri);}}
    String val(EditText e){return e.getText().toString();}
    void saveForm(){getPreferences(0).edit().putString("job",val(job)).putString("date",val(date)).putString("client",val(client)).putString("address",val(address)).putString("contact",val(contact)).putString("installer",val(installer)).putString("work",val(work)).putString("defects",val(defects)).putString("notes",val(notes)).putBoolean("accepted",accepted.isChecked()).putBoolean("conditional",conditional.isChecked()).apply();}
    void loadForm(){android.content.SharedPreferences p=getPreferences(0);job.setText(p.getString("job",""));date.setText(p.getString("date",date.getText().toString()));client.setText(p.getString("client",""));address.setText(p.getString("address",""));contact.setText(p.getString("contact",""));installer.setText(p.getString("installer",""));work.setText(p.getString("work",""));defects.setText(p.getString("defects",""));notes.setText(p.getString("notes",""));accepted.setChecked(p.getBoolean("accepted",false));conditional.setChecked(p.getBoolean("conditional",false));}
    File createPdf(){
        saveForm(); PdfDocument doc=new PdfDocument(); PdfDocument.PageInfo pi=new PdfDocument.PageInfo.Builder(595,842,1).create(); PdfDocument.Page page=doc.startPage(pi); Canvas c=page.getCanvas(); Paint p=new Paint();p.setColor(Color.BLACK);p.setTextSize(12);
        int y=40; p.setTextSize(16);p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("I.D.T. STEELWORKS AND ENGINEERING",30,y,p);y+=25;p.setTextSize(13);c.drawText("CLIENT INSTALLATION SIGN-OFF",30,y,p);y+=35;p.setTypeface(Typeface.DEFAULT);
        String[][] rows={{"Job",val(job)},{"Date",val(date)},{"Client",val(client)},{"Address",val(address)},{"Contact",val(contact)},{"Installer",val(installer)},{"Work Installed",val(work)},{"Defects",val(defects)},{"Notes",val(notes)},{"Accepted",accepted.isChecked()?"YES":"NO"},{"Conditional",conditional.isChecked()?"YES":"NO"}};
        for(String[] row:rows){y=drawWrapped(c,row[0]+": "+row[1],30,y,p,540);y+=8;if(y>760)break;}
        y=Math.min(y,690);p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("Client Signature",30,y,p);c.drawBitmap(clientSignature.getBitmap(),null,new Rect(30,y+8,280,y+100),p);c.drawText("Installer Signature",315,y,p);c.drawBitmap(installerSignature.getBitmap(),null,new Rect(315,y+8,565,y+100),p);
        doc.finishPage(page);
        try{File f=new File(getCacheDir(),"IDT_Signoff_"+System.currentTimeMillis()+".pdf");FileOutputStream out=new FileOutputStream(f);doc.writeTo(out);out.close();doc.close();return f;}catch(Exception e){doc.close();Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();return null;}
    }
    int drawWrapped(Canvas c,String s,float x,int y,Paint p,int max){String[] words=s.split(" ");String line="";for(String w:words){if(p.measureText(line+w)>max){c.drawText(line,x,y,p);y+=16;line="";}line+=w+" ";}c.drawText(line,x,y,p);return y+16;}
    void sharePdf(File f){if(f==null)return;Uri u=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f);Intent i=new Intent(Intent.ACTION_SEND);i.setType("application/pdf");i.putExtra(Intent.EXTRA_SUBJECT,"IDT Installation Sign-Off");i.putExtra(Intent.EXTRA_TEXT,"Please find attached the IDT installation sign-off report.");i.putExtra(Intent.EXTRA_STREAM,u);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Share PDF report via WhatsApp or email"));}
}
